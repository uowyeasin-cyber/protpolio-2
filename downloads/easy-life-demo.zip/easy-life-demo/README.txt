Easy Life · live demo
======================

This is the clickable demo of Easy Life, an AI life assistant for Android.
Open index.html (English) or bn.html (Bangla) in any browser (Chrome is best) and tap around.
It shows every screen; nothing is saved and no AI runs in the demo.

The Android beta is free to download: https://github.com/uowyeasin-cyber/super-note/releases/latest/download/easy-life-beta.apk
Pro: pre-order on WhatsApp +60178151865
or see plans and prices at https://yeasinarafatbd.vercel.app/easy-life/

---

সুপার নোট · লাইভ ডেমো

index.html ফাইলটা যেকোনো ব্রাউজারে খুলুন (Chrome সবচেয়ে ভালো), তারপর চাপ দিয়ে ঘুরে দেখুন।
এখানে সব স্ক্রিন দেখা যাবে। ডেমোতে কিছু সেভ হয় না, আর AI চলে না।

Android বেটা ফ্রিতে ডাউনলোড করুন: https://github.com/uowyeasin-cyber/super-note/releases/latest/download/easy-life-beta.apk
Pro নিতে WhatsApp করুন: +60178151865
প্ল্যান ও দাম: https://yeasinarafatbd.vercel.app/easy-life/
