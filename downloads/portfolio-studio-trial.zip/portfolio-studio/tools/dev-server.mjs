// Local development server: the production server with caching turned off.
// Edits are stored in ./.cms-data (or CMS_DATA_DIR).
import { createServer } from "../server.mjs";

const port = +process.env.PORT || 3000;
createServer({ dev: true }).listen(port, () => console.log("http://localhost:" + port));
