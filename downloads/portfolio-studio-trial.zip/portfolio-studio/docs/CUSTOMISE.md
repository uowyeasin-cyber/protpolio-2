# Customisation guide

How to turn the demo ("Alex Morgan") into your client's real portfolio, make it rank on Google, and hand it over. For installing and deploying, see [README.md](../README.md).

## 1. Put in the client's content
1. Open `data/content.js`.
2. Fill in the `SITE` block at the top: name, initials, role, email, WhatsApp number (digits only, with country code), phone, location, LinkedIn, GitHub, facts and client names. The header, hero, buttons, contact page and résumé all read from it.
3. Replace the lists below it: `PROJECTS` (case studies), `DEV` (apps and websites), `UIX` (UI/UX cards), `SERVICES`, `PACKAGES`, `EDU`, `EXP`, `SKILLS`, `CREDS`, `TESTIMONIALS`, `FAQ`, `BOT` (chatbot answers) and `CV` (résumé). Every list has a comment that explains its shape.
4. Put the client's images in `img/` with the same names, or use new names and update `content.js`. Keep a small `-t.webp` thumbnail next to each gallery image. Replace `avatar.webp` (their photo, 4:5), `logo.webp` (square) and `og.jpg` (1200×630 link preview). Replace `resume.pdf` with the client's résumé too (open the site, go to Résumé, press Download PDF, and save the file as `resume.pdf`).
5. In `index.html`, change the five SEO lines at the top of `<head>` (description and Open Graph title). The hero headline and About text are in `index.html` too, or the client can change them later in Customise mode.

## 2. Get found on Google (SEO)
1. In `data/content.js`, fill `SITE.url` (the live address), `SITE.description` (one clear sentence with the client's job and city) and `SITE.keywords` (what people would type into Google).
2. In `index.html`, change the SEO lines at the top of `<head>` to match, so link previews look right even before the page runs.
3. In `robots.txt` and `sitemap.xml`, replace `example.com` with the client's address. Add a line to the sitemap for each demo page or PDF.
4. Open [Google Search Console](https://search.google.com/search-console), add the site as a URL-prefix property, choose **HTML tag**, paste that tag under the comment in `<head>`, deploy, then press **Verify**. Then go to **Sitemaps** and submit `sitemap.xml`. Do the same in [Bing Webmaster Tools](https://www.bing.com/webmasters) (it can import from Google).
5. **Service pages:** edit `SERVICE_PAGES` at the bottom of `data/content.js` (one entry per service: title, description, keywords, examples, FAQ, and an optional second-language section), then run `node tools/build-service-pages.mjs`. It writes a search-ready page for each service under `services/`, a `services/` hub, and a fresh `sitemap.xml`, so searches like "logo designer in <city>" can land on the right page. Run it again whenever you change `SITE.url` or the services, and commit the output. Delete the entries you don't need. Keep each `desc` under 155 characters, or add a shorter `meta:"..."` line to the entry: that becomes the search-result description (Bing flags descriptions over 160 characters as an error) while `desc` stays on the page.
6. **Other languages:** every service page has a "Read this in your language" row (Bangla, Malay, Indonesian, Arabic, Hindi, Urdu, Chinese, Spanish). The text is in `data/i18n.js`: `NAMES` holds each service's name and one sentence per language, and `LANGS` holds the shared sentences. Remove a language by deleting its entry in `LANGS`. Hindi and Urdu sentences are written in the masculine first person; change "करता/बनाता" to "करती/बनाती" and "کرتا/بناتا" to "کرتی/بناتی" for a woman. Run `node tools/build-service-pages.mjs` after any change.
7. **Name and icon in search results:** set `SITE.siteName` (shown instead of "vercel.app") and `SITE.alternateNames`. The client can change the site icon any time in Customise > Theme > Site icon; replace `img/icon-512.png` and `favicon.ico` for the default.
8. **Bing, Yahoo, DuckDuckGo, Yandex and others:** add the site to [Bing Webmaster Tools](https://www.bing.com/webmasters) (import from Google in one click). For instant updates, put 32 random letters/numbers in `SITE.indexNowKey`, run the service-page builder (it writes the key file), deploy, then run `node tools/indexnow.mjs`. The included GitHub workflow (`.github/workflows/indexnow.yml`) runs it for you after every production deploy. `llms.txt` (also written by the builder) helps AI search tools such as ChatGPT and Perplexity describe the client correctly.
9. Tell the client what helps most: a custom domain, the site link on their LinkedIn, GitHub and social profiles, and links from their other websites. Rankings take weeks and nobody can guarantee a position.

## 3. Handing it over to the client
- Give them the site link, the `/#login` link, and their email and password (set by them in Vercel, or shared privately, never in the code).
- Show them: Customise → Edit to change text and photos, Theme to change colours and fonts, Pages to add or hide pages, and **Publish** to make changes live. History rolls back any change.
- If they want to change their password later, update `OWNER_PASSWORD` in Vercel and redeploy. That signs out every old session.

## 4. Rebranding colours and fonts
- Quickest: sign in, open Customise → Theme, and pick a preset or your own colours and fonts.
- To open in light instead of dark: in `index.html`, change `data-theme="dark"` on the `<html>` tag to `light`, and in the small script just after `<body>` swap `"light":"dark"` to `"dark":"light"` and `t==="light"` to `t==="dark"`.
- In code: the light theme colours are the `:root` tokens at the top of the `<style>` block in `index.html`, and the dark theme colours are under `:root[data-theme="dark"]`.

## 5. Licence notes
- Fonts: Geist and Geist Mono use the SIL Open Font License (commercial use allowed). `@vercel/blob` is Apache-2.0. html2pdf.js is MIT (licence notes in `vendor/`).
- The terms of use are in `LICENSE`. Third-party licences are listed in `THIRD-PARTY-NOTICES.md`.
- Use only images you own or have a licence for. The placeholder images in `img/` are generated and free to use.
- Never commit `.env`, `.cms-data/` or `node_modules/`. They are already in `.gitignore`.
