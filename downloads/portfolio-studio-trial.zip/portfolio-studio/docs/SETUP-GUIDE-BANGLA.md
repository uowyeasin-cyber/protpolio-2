# Setup guide (Banglish): client er jonno site live kora, step by step

Ei guide follow korle ekta notun client er portfolio site 30 to 60 minute e live hobe. Kono coding lagbe na, shudhu copy-paste.

---

## Age theke ja lagbe
1. **Node.js** (version 20 ba 22): https://nodejs.org theke "LTS" download kore install koro.
2. **GitHub account** (free): https://github.com
3. **Vercel account** (free): https://vercel.com, "Continue with GitHub" diye sign up koro.
4. Client er info: naam, kaj (role), email, WhatsApp number, city, LinkedIn/GitHub link, photo, project gula (chobi + short description), services, résumé.

---

## Step 1: Folder ta khulo ar computer e chalao
1. Zip ta unzip koro. `portfolio-studio` folder ta pabe.
2. Folder ta VS Code e open koro (File → Open Folder).
3. VS Code e Terminal kholo (Terminal → New Terminal) ar ei command gula dao:
   ```
   npm install
   npm run dev
   ```
4. Browser e http://localhost:3000 kholo. Demo site ("Alex Morgan") dekhbe. Tar mane sob thik ache.

## Step 2: Client er info boshao
1. `data/content.js` file ta kholo.
2. Upore `SITE = { ... }` block e client er naam, initials, role, email, WhatsApp (shudhu number, country code soho, jemon `8801712345678`), phone, location, LinkedIn, GitHub boshao.
3. Niche `PROJECTS`, `DEV`, `UIX`, `SERVICES`, `PACKAGES`, `EDU`, `EXP`, `SKILLS`, `CREDS`, `TESTIMONIALS`, `FAQ`, `BOT` (chatbot er uttor), `CV` (résumé) list gula change koro. Protita list er upore comment e lekha ache ki format e likhte hobe. Same format rakho, shudhu lekha bodlao.
4. `img/` folder e client er chobi rakho:
   - `avatar.webp`: client er photo (4:5 ratio)
   - `logo.webp`: logo (square)
   - `og.jpg`: Facebook/WhatsApp e link share korle je chobi dekhay (1200×630)
   - project er chobi: boro ta `name.webp`, choto thumbnail `name-t.webp`
   - Tip: chobi WebP banate https://squoosh.app use koro.
5. `index.html` er ekdom upore `<head>` er moddhe title ar description line gula client er naam diye bodlao.
6. Terminal e `npm run build` dao. Eta service page, sitemap ar llms.txt notun kore banabe.
7. Browser refresh kore check koro sob thik dekhache kina. Phone size eo check koro (browser e F12 → phone icon).

## Step 3: GitHub e upload koro
1. GitHub e **New repository** banao (jemon `client-name-portfolio`). Private rakhleo hobe.
2. Sobcheye shohoj upay: GitHub Desktop (https://desktop.github.com) install koro → File → Add local repository → `portfolio-studio` folder → Publish repository.
   - Ba terminal diye:
   ```
   git init
   git add .
   git commit -m "Client portfolio"
   git branch -M main
   git remote add origin https://github.com/TOMAR-USERNAME/client-name-portfolio.git
   git push -u origin main
   ```

## Step 4: Vercel e live koro
1. https://vercel.com → **Add New → Project** → GitHub repo ta select koro → **Deploy**. (Framework "Other" thakbe, build command lagbe na.)
2. 1 minute e site live: `something.vercel.app`.
3. Project er **Storage** tab → **Create → Blob** → naam dao → **Connect** (project e). Eta client er edit ar upload save korar jayga.
4. **Settings → Environment Variables** e add koro:
   - `OWNER_EMAIL` = client er email
   - `OWNER_PASSWORD` = client er password (client nije set korle best)
5. **Deployments** tab → latest deployment er pashe **⋯ → Redeploy**. (Variable add korar por redeploy na korle login kaj korbe na.)

## Step 5: Customise mode check koro
1. `https://client-site.vercel.app/#login` kholo.
2. Client er email ar password diye sign in koro.
3. Niche ekta bar ashbe: **Edit**, **Publish**, **Theme**, **Pages**, **History**.
4. Kono lekha te click kore change koro → **Publish** chapo → onno browser e (incognito) site kholo, change ta dekhbe.

## Step 6: Domain lagao (jodi client er domain thake)
1. Vercel project → **Settings → Domains → Add** → domain likho (jemon `clientname.com`).
2. Vercel je DNS record dekhabe (A record ba CNAME), seta domain kina jayga (Namecheap, GoDaddy, etc.) te boshao.
3. 10 minute theke kichu ghonta lagte pare. HTTPS Vercel nije kore dey.
4. Domain lagar por `data/content.js` e `SITE.url` notun domain diye bodlao, `robots.txt` ar `sitemap.xml` e `example.com` bodlao, `npm run build` dao, abar push koro.

## Step 7: Google e ana (SEO)
1. https://search.google.com/search-console → site add koro (URL prefix) → **HTML tag** choose koro → tag ta `index.html` er `<head>` e comment er niche paste koro → push → **Verify**.
2. **Sitemaps** e `sitemap.xml` submit koro.
3. Bing er jonno https://www.bing.com/webmasters → "Import from Google".
4. Details: `docs/CUSTOMISE.md` er "Get found on Google" section.

## Step 8: Client ke handover
Client ke dao:
- Site er link
- Login link: `https://site/#login`
- Email ar password (WhatsApp/private e, kokhono code e na)
- Dekhiye dao: **Edit** diye lekha/chobi change, **Theme** diye color/font, **Pages** diye page add/hide, **Publish** diye live kora, **History** diye ager version e ferot jawa.
- Password change korte chaile: Vercel e `OWNER_PASSWORD` bodlao → Redeploy.

---

## Vercel na diye nijer server (VPS) e chalate chaile
Docker thakle:
```
cp .env.example .env      # .env file e OWNER_EMAIL, OWNER_PASSWORD likho
docker compose up -d --build
```
Site chalbe `http://SERVER-IP:3000` e. Login er jonno HTTPS lagbe: `docker-compose.yml` e `caddy` part ta uncomment koro, `Caddyfile` e domain likho, abar `docker compose up -d` dao. Details README.md er "Route B" te.

## Problem hole
| Problem | Somadhan |
|---|---|
| "The editor is not set up yet" | Vercel e `OWNER_EMAIL`/`OWNER_PASSWORD` nai, ba add korar por Redeploy koro nai |
| Login hoy kintu Publish fail | Blob store connect hoy nai, ba connect korar por Redeploy koro nai |
| "Too many attempts" | 8 bar bhul password dile 15 minute wait korte hoy |
| Change dekha jacche na | 30 second wait kore refresh koro |
| Chobi upload hocche na | 4 MB er beshi. https://squoosh.app diye choto koro |
| `npm` command kaj kore na | Node.js install hoy nai. nodejs.org theke install kore VS Code abar kholo |
