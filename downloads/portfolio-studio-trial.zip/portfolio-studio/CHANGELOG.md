# Changelog

## 1.0.0 (2026-11-08)
First marketplace release.
- Portfolio site: Home, Work, Code, Awards, Services, About, Résumé (PDF), Contact, case studies, chatbot, light/dark themes.
- Customise mode: owner login, visual editing, theme presets, pages, version history and rollback, media upload.
- SEO: meta/OG/schema.org, sitemap, robots, llms.txt, 7 service pages in 8 languages, IndexNow workflow.
- Deployment: Vercel (Blob storage) and Docker/VPS (`server.mjs`, `Dockerfile`, `docker-compose.yml`, optional Caddy HTTPS).
- Security: path-traversal and private-file protection, security headers, sandboxed uploads, dependency override (0 known vulnerabilities).
- Demo mode (`DEMO_MODE=1`) for a public live demo: visitors can try the editor, nothing is saved.
- Automated tests (`npm test`).
