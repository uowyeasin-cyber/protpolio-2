// ============================================================
// Site content. Every text, list, card, gallery piece and chatbot
// answer on the site comes from this file. Replace the demo
// content below with your client's details, then swap the images
// in /img (name-t.webp is the thumbnail of name.webp).
// ============================================================

// Your client's details. Used across the header, hero, buttons, forms and résumé.
const SITE = {
  name: "Alex Morgan",
  initials: "AM",
  role: "Product designer & developer",
  siteName: "Alex Morgan | Studio",   // the name search engines show next to results
  alternateNames: ["Alex Morgan Studio"], // other names people search for (brand, username)
  indexNowKey: "",                    // optional: 32 letters/numbers, see README Step 4
  tagline: "Apps · Design · AI Agents",
  email: "hello@example.com",
  whatsapp: "15550100000",          // country code + number, digits only
  phone: "+1 555 010 0000",
  location: "Your City, Country",
  linkedin: "https://www.linkedin.com/",
  github: "https://github.com/",
  youtube: "",                       // optional social links: used in search data (sameAs) on the service pages
  facebook: "",
  instagram: "",
  resume: "#cv",                    // a link to a PDF, or #cv for the built-in résumé page
  // SEO: the live address, one sentence about the person, and words people might search for.
  url: "https://example.com/",
  description: "Product designer and developer building apps, websites and UI/UX for startups and small businesses.",
  keywords: ["product designer","web developer","app developer","UI/UX designer","portfolio"],
  city: "Your City", country: "US",
  areas: ["United States","Worldwide"],  // where you take clients, used on the service pages
  languages: ["English"],
  photo: "img/avatar.webp",
  logo: "img/logo.webp",
  // Four numbers under the hero: [big value, label].
  facts: [["24","Projects shipped"],["8 yrs","Designing and building"],["15","Happy clients"],["4.9","Average client rating"]],
  // Names that scroll under the hero.
  clients: ["Northwind","Bluepeak","Lumen Labs","Harbor & Co","Atlas Studio","Kite Health","Fieldnote","Orbit Coffee"],
};

// Image sizes [width, height] for every gallery piece (used for layout before images load).
const META = {"case-1":[1600,1000],"case-2":[1600,1000],"brand-1":[800,800],"brand-2":[800,800],"brand-3":[800,800],"brand-4":[800,800],"print-1":[1000,1400],"print-2":[1000,1400],"print-3":[1000,1400],"social-1":[1080,1350],"social-2":[1080,1350],"social-3":[1080,1350],"social-4":[1080,1350],"web-1":[1600,1000],"web-2":[1600,1000],"app-1":[1600,1000],"app-2":[1600,1000],"ui-1":[1200,900],"ui-2":[1200,900],"ui-3":[1200,900],"ui-4":[1200,900]};

// Gallery pieces: id: [title, category, spec]. Category is one of the CATS keys below.
const P = {
  "case-1":["Northwind app, overview","case","Case study cover"],
  "case-2":["Bluepeak rebrand, overview","case","Case study cover"],
  "brand-1":["Northwind logo","branding","Logo · 800×800"],
  "brand-2":["Bluepeak monogram","branding","Logo · 800×800"],
  "brand-3":["Orbit Coffee badge","branding","Logo · 800×800"],
  "brand-4":["Kite Health mark","branding","Logo · 800×800"],
  "print-1":["Product brochure, cover","print","Brochure · A4"],
  "print-2":["Product brochure, inside","print","Brochure · A4"],
  "print-3":["Event poster","print","Poster · A3"],
  "social-1":["Launch post","social","Post · 1080×1350"],
  "social-2":["Feature post","social","Post · 1080×1350"],
  "social-3":["Testimonial post","social","Post · 1080×1350"],
  "social-4":["Offer post","social","Post · 1080×1350"],
  "web-1":["Bluepeak website","web","Website · 1440px"],
  "web-2":["Atlas Studio website","web","Website · 1440px"],
  "app-1":["Northwind app","web","App · dashboard"],
  "app-2":["Kite Health app","web","App · mobile"],
};

// Videos in /vid with a poster in /img/<id>-poster.jpg. Leave empty if there are none.
const VIDEOS = {};

// Archive filter categories.
const CATS = [["all","All"],["web","Apps & Web"],["branding","Branding"],["print","Print"],["social","Social Media"]];

// Design case studies (each gets its own page at #p-<slug>).
const PROJECTS = [
  {slug:"northwind", name:"Northwind", client:"Northwind Logistics", year:"2026", cover:"case-1",
   scope:"Product design & build", tags:["UX research","App","Design system"],
   summary:"A delivery-tracking app for a logistics company. Research, wireframes, a design system and a working web app that cut support calls by a third.",
   deliver:"Research, UI design, design system, web app",
   groups:[
     {h:"The product",p:"A dashboard for dispatchers and a simple tracking page for customers.",cols:2,items:["app-1","case-1"]},
     {h:"Identity",p:"A clean mark that works as an app icon and on the side of a van.",cols:2,fit:true,items:["brand-1","brand-4"]},
   ]},
  {slug:"bluepeak", name:"Bluepeak", client:"Bluepeak Outdoor", year:"2025", cover:"case-2",
   scope:"Brand & website", tags:["Branding","Website","Social"],
   summary:"A new identity and website for an outdoor gear shop, plus launch posts that kept the feed looking like one brand.",
   deliver:"Logo, website, brochure, 4 social posts",
   groups:[
     {h:"Website",p:"A fast storefront with a clear path from product to checkout.",cols:1,items:["web-1"]},
     {h:"Print",p:"A brochure for the shop counter and an event poster.",cols:3,items:["print-1","print-2","print-3"]},
     {h:"Social media",p:"Launch posts in one layout system.",cols:4,items:["social-1","social-2","social-3","social-4"]},
   ]},
];

// Services page cards. i = inner SVG of a 24×24 line icon.
// r = rating out of 5 shown on the card (set the real client rating; delete r to hide it).
// rn = optional review count text, e.g. "12 reviews". go = the /services/<slug>/ page the card opens (from SERVICE_PAGES). Cards are shown in this order; the first 4 also show on Home.
const SERVICES = [
  {r:4.9,go:"app-development",t:"Mobile & web apps",p:"Apps with logins, data and payments, designed to be easy from the first tap.",l:["iOS, Android & web (PWA)","Dashboards & accounts","Payments & bookings"],i:'<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>'},
  {r:5.0,go:"website-development",t:"Websites & online stores",p:"Fast business sites and stores, built to rank on Google and load quickly on phones.",l:["Business & landing pages","E-commerce","Hosting, domain & SEO setup"],i:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M7 6.5h.01M10 6.5h.01"/>'},
  {r:4.9,go:"ui-ux-design",t:"Web design & UI/UX",p:"Wireframes, app screens and design systems, tested so people find what they need.",l:["Wireframes & prototypes","App & website screens","Design systems"],i:'<path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.6 7.6"/><circle cx="11" cy="11" r="2"/>'},
  {r:4.8,go:"seo-services",t:"SEO & Google ranking",p:"Help customers find you on Google: technical SEO, keywords, page speed and a Google Business Profile.",l:["Keyword research & on-page SEO","Search Console, sitemap & structured data","Page speed & Google Business Profile"],i:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/><path d="M8 13l2-2 2 2 3-3"/>'},
  {r:4.9,go:"ai-automation",t:"AI agents & automation",p:"AI agents, assistants and automations that answer customers, take bookings and orders, and run the repetitive work for you.",l:["AI chat assistants for websites & WhatsApp","Automated replies, forms, emails & reports","OpenAI, Gemini & no-code integrations"],i:'<rect x="5" y="8" width="14" height="11" rx="2"/><path d="M12 8V4M9 4h6M9 13h.01M15 13h.01M10 16h4M3 12v3M21 12v3"/>'},
  {r:5.0,go:"portfolio-website",t:"Portfolio websites",p:"A personal portfolio with your work, résumé and a private editor to update it yourself.",l:["Light & dark themes","Case studies & résumé","Owner-only editor"],i:'<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>'},
  {r:4.9,go:"graphic-design",t:"Brand identity",p:"Logos and visual systems that work as a tiny app icon and on a shop sign.",l:["Logo & monogram","Colour and type system","Brand guidelines"],i:'<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>'},
  {r:4.8,go:"graphic-design",t:"Social media design",p:"Posts, covers and reels that keep a feed looking like one brand.",l:["Posts & reels","Covers & banners","Launch campaigns"],i:'<rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="12" cy="12" r="3.5"/><circle cx="17" cy="7" r=".6"/>'},
];

// Software toolkit tiles: [badge, name, use, text colour, badge colour].
const TOOLS = [["Re","React","Web & mobile UI","#61DAFB","#20232A"],["Nx","Next.js","Full-stack websites","#fff","#000"],["TS","TypeScript","Safer app code","#fff","#3178C6"],["JS","JavaScript","Interaction","#000","#F7DF1E"],["Tw","Tailwind CSS","Fast styling","#fff","#0EA5E9"],["Nd","Node.js","Servers & APIs","#fff","#3C873A"],["Fb","Firebase","Login & live data","#fff","#DD2C00"],["Pg","PostgreSQL","Databases","#fff","#336791"],["Py","Python","Programming","#FFD43B","#306998"],["Jv","Java","OOP & Spring Boot","#fff","#E76F00"],["St","Stripe","Online payments","#fff","#635BFF"],["Fg","Figma","UI/UX design","#fff","#A259FF"],["GSC","Search Console","Google indexing","#fff","#4285F4"],["Gm","Gemini","AI features","#fff","#1A73E8"],["Gh","GitHub","Code & projects","#fff","#24292F"],["Ps","Photoshop","Photo editing","#31A8FF","#001E36"],["Ai","Illustrator","Logos & vectors","#FF9A00","#330000"],["Pr","Premiere Pro","Video editing","#9999FF","#00005B"]];

// Education rows: [dates, title, detail, score, optional [link label, url]].
const EDU = [
  ["2016 – 2020","Bachelor of Design, Interaction Design","Example University · Dean's list, design society lead.","First"],
  ["2021","Google UX Design Certificate","Online professional certificate.","",["See credentials","#awards"]],
];

// Work history rows: same shape as EDU.
const EXP = [
  ["2023 – now","Independent product designer & developer","Design and build apps and websites for startups and small businesses.",""],
  ["2020 – 2023","Product designer · Lumen Labs","Led design for a B2B analytics product used by 4,000 teams.",""],
  ["2018 – 2020","Junior web designer · Atlas Studio","Designed and built marketing sites for local brands.",""],
];

// Co-curricular and leadership rows: same shape as EDU.
const COCUR = [
  ["2022 – now","Mentor · Design community","Monthly portfolio reviews for new designers.",""],
  ["2021","Speaker · Local design meetup","Talk on design systems for small teams.",""],
];

// Skill cards on the About page.
const SKILLS = [
  ["Product & UX design","Research, flows, wireframes and usability tests."],
  ["UI & visual design","Interfaces, design systems, typography and colour."],
  ["Front-end development","HTML, CSS, JavaScript, React and Next.js."],
  ["Communication","Clear briefs, weekly updates and fast revisions."],
];

// Short skill tags under the skill cards.
const SKILL_TAGS = ["UX research","Wireframing","Prototyping","Design systems","UI design","Branding","HTML","CSS","JavaScript","TypeScript","React","Next.js","Node.js","SEO","Accessibility"];

// Software projects (Code page and the Apps / Websites / Systems sections of Work).
// cat: "app", "web" or "system". home: true shows it on the home page. img: an image in /img (optional).
// Add demo:"name" to play /demo/name.html inline, with a poster at /img/demo-name.jpg.
const DEV = [
  {n:"Northwind",k:"Logistics app",cat:"app",home:true,img:"app-1",tags:["React","Node.js","PostgreSQL"],
   p:"A delivery-tracking app with a dispatcher dashboard and a live tracking page for customers.",
   l:["Live map with driver locations","Role-based accounts for dispatchers and drivers","Cut support calls by a third"],link:["Open the app","#"]},
  {n:"Kite Health",k:"Mobile health app",cat:"app",home:true,img:"app-2",tags:["React Native","Firebase"],
   p:"A simple app for booking clinic visits and keeping health records in one place.",
   l:["Booking in three taps","Reminders and secure records","Works offline"]},
  {n:"Bluepeak store",k:"E-commerce website",cat:"web",home:true,img:"web-1",url:"bluepeak.example",tags:["Next.js","Stripe","SEO"],
   p:"A fast online store with a clear path from product to checkout.",
   l:["Product filters and search","Card and wallet payments","Loads in under a second"]},
  {n:"Atlas Studio",k:"Business website",cat:"web",img:"web-2",url:"atlas.example",tags:["Next.js","CMS"],
   p:"A portfolio website for an architecture studio, edited by the team without code.",
   l:["Project case studies","Editable content","Contact and booking forms"]},
  {n:"AI Agent Front Desk",k:"AI agents & automation · live prototype",cat:"system",home:true,img:"dev-ai-agent",demo:"ai-agent",link:["Open the prototype","demo/ai-agent.html"],tags:["AI agent","Tool calling","WhatsApp","Automation"],
   p:"An AI agent that runs the front desk of a restaurant: it answers questions, books tables, takes orders, tracks riders and hands complaints to a manager, while a live panel shows every step it takes.",
   l:["Fills booking details over several messages, one short question at a time","Calls tools for availability, bookings, orders, payment links and Google Sheets","Hands over to a person instead of guessing","An Automations view with six business workflows"]},
  {n:"Ordering system",k:"Web app · live prototype",cat:"system",img:"dev-ordering",demo:"ordering-prototype",link:["Open the prototype","demo/ordering-prototype.html"],tags:["Node.js","PostgreSQL","Docker"],
   p:"A food ordering web app with a menu, cart, checkout and live order tracking, backed by a REST API.",
   l:["JWT auth and rate limits","Tests and CI","Docker deploy"],
   code:`<span class="c">// routes</span>\n<span class="k">POST</span>   /api/bookings   <span class="s">201</span>\n<span class="k">GET</span>    /api/bookings   <span class="s">200</span>\n<span class="k">DELETE</span> /api/bookings/:id <span class="s">204</span>`},
];

// UI/UX & web design cards on the Work page: [title, kind, image, link, text, video].
// video is optional: "my-demo" plays vid/my-demo.mp4 (muted, looping) with img/my-demo-poster.jpg as its poster.
// A link starting with demo/ opens in a new tab.
const UIX = [
  ["Dispatcher dashboard","App design · Northwind","ui-1.webp","#p-northwind","Clear status at a glance for a busy dispatch team."],
  ["Booking flow","App design · Kite Health","ui-2.webp","#work","Three taps from opening the app to a confirmed visit."],
  ["Store checkout","Web design · Bluepeak","ui-3.webp","#p-bluepeak","A one-page checkout that lifted completed orders."],
  ["Studio website","Web design · Atlas Studio","ui-4.webp","#work","Big imagery, calm type and simple navigation."],
];

// Learning or open-source projects on the Code page: [kind, repo name, description, private?].
const REPOS = [
  ["JavaScript","ui-components","Accessible UI components with keyboard support."],
  ["TypeScript","design-tokens","A small library that turns design tokens into CSS variables."],
];

// Licences and certifications. img: an image in /img for the certificate (optional).
// tag: an optional highlight chip, e.g. tag:"30% tuition fee waiver".
const CREDS=[
  {t:"Google UX Design Certificate",iss:"Google · Coursera",d:"Issued 2021",id:"EXAMPLE-123",note:"Seven-course professional certificate in UX design."},
  {t:"Accessibility Fundamentals",iss:"Example Academy",d:"Issued 2022",note:"WCAG 2.2 and inclusive design."},
  {t:"Merit Scholarship",iss:"Example University",d:"Awarded 2020",tag:"30% tuition fee waiver",note:"Merit scholarship for outstanding academic results."},
];

// Client quotes, e.g. {q:"…", n:"Name", r:"Owner, Business"}. The section stays hidden while this is empty.
const TESTIMONIALS=[
  {q:"Alex turned a messy brief into an app our drivers actually like using.",n:"Jamie Lee",r:"Operations lead, Northwind"},
  {q:"Fast, clear and calm. Our new site paid for itself in a month.",n:"Sam Rivera",r:"Owner, Bluepeak Outdoor"},
];

// Service packages. price: "" shows "Custom quote"; put e.g. "From USD 499" to show a price.
const PACKAGE_TABS={apps:"Apps",dev:"Websites",uiux:"UI/UX",seo:"SEO",ai:"AI agents",design:"Design & video"};
const PACKAGES={
  apps:[
    {t:"Starter app",f:"A first version of your idea that people can install and use.",price:"From USD 499",d:"Launch fast",l:["Installable app for Android, iPhone & web (PWA)","Up to 5 screens","Login and a simple database","Published and live for you"]},
    {t:"Business app",f:"An app your customers or team use every day.",price:"From USD 999",d:"Most popular",pop:1,l:["Everything in Starter app","User accounts and admin dashboard","Payments, bookings or orders","Push notifications and offline mode","2 months of fixes after launch"]},
    {t:"Custom platform",f:"A bigger product with several user types or AI features.",price:"From USD 1,999",d:"Custom build",l:["Several roles (customer, staff, admin)","AI features such as chat or smart search","Integrations and APIs","Tests and documentation"]},
  ],
  dev:[
    {t:"Portfolio or landing page",f:"One polished site that shows who you are or what you sell.",price:"From USD 149",d:"Fast turnaround",l:["Responsive, mobile-first design","Contact form or WhatsApp button","Basic SEO and analytics","Deployed live for you"]},
    {t:"Business website",f:"A multi-page site you can grow.",price:"From USD 349",d:"Most popular",pop:1,l:["Up to 6 pages in Next.js","Your brand, copy and images","Fast load and good Lighthouse score","Hosting and domain setup"]},
    {t:"Web app or store",f:"Accounts, data, payments or a dashboard.",price:"From USD 799",d:"Custom build",l:["Login and user accounts","Database (PostgreSQL or MySQL)","Payments, orders or bookings","Admin dashboard","Tests and documentation"]},
  ],
  uiux:[
    {t:"Screen design",f:"A few key screens designed properly.",price:"From USD 99",d:"Quick start",l:["Up to 5 app or web screens","Mobile and desktop versions","Figma source file","2 rounds of revisions"]},
    {t:"Full UI/UX design",f:"A whole app or website, ready to build.",price:"From USD 299",d:"Most popular",pop:1,l:["Wireframes and user flow","All screens, mobile and desktop","Clickable prototype","Developer handoff"]},
    {t:"Design system",f:"One consistent look across every product.",price:"From USD 599",d:"Complete system",l:["Colours, type and spacing tokens","Buttons, forms and components","Usage guidelines","Figma library"]},
  ],
  seo:[
    {t:"SEO setup",f:"Get a new or existing site ready for Google.",price:"From USD 79",d:"One-time",l:["Titles, descriptions and headings","Sitemap, robots.txt and structured data","Google Search Console setup","Speed and mobile check"]},
    {t:"SEO growth",f:"Climb for the searches that bring customers.",price:"From USD 149 / month",d:"Most popular",pop:1,l:["Keyword research for your market","New and improved pages each month","Technical fixes and speed work","Monthly ranking report"]},
    {t:"Local SEO",f:"Show up on Google Maps in your area.",price:"From USD 99",d:"For local shops",l:["Google Business Profile setup","Local keywords and pages","Reviews and photos guidance","Listings in your languages"]},
  ],
  ai:[
    {t:"AI assistant",f:"A smart assistant that answers your customers 24/7.",price:"From USD 199",d:"Quick win",l:["Chatbot for your website or WhatsApp","Trained on your products, prices and FAQs","Hands over to you when needed","Setup and testing included"]},
    {t:"AI automation",f:"Take repetitive work off your team's plate.",price:"From USD 399",d:"Most popular",pop:1,l:["Automated replies, bookings and follow-ups","Forms, sheets, emails and reports connected","AI that sorts, summarises and drafts","1 month of support and tweaks"]},
    {t:"AI agent",f:"An agent that takes real actions in your business tools.",price:"From USD 999",d:"Custom build",l:["AI features inside your own app or dashboard","OpenAI, Gemini or other models","Your data kept private and secure","Tests and documentation"]},
  ],
  design:[
    {t:"Starter",f:"A single piece that needs to look right.",price:"From USD 25",d:"Fast turnaround",l:["Logo, poster, flyer or 3 social posts","2 concepts to choose from","Print and web files","2 rounds of revisions"]},
    {t:"Brand kit",f:"A new shop, restaurant or page getting started.",price:"From USD 129",d:"Most popular",pop:1,l:["Logo with colour and type system","Menu or brochure, print-ready","5 social posts and a cover","Source files included","3 rounds of revisions"]},
    {t:"Full launch",f:"Everything a launch needs, in one style.",price:"From USD 299",d:"Complete system",l:["Everything in Brand kit","LED or TV menu board","Promo video or reel","Launch campaign posts","Priority support"]},
  ],
};

// Questions on the Services page.
const FAQ=[
  ["How do we start?","Send a short brief on WhatsApp, by email or with the form on the Contact page. I reply within 24 hours with questions and a fixed quote."],
  ["How does payment work?","You approve the quote before I start. Bigger projects are split into a deposit and a final payment on delivery."],
  ["Do you work with clients abroad?","Yes. I work remotely with clients in any time zone."],
  ["What will I get?","The live site or app, the source files and a short guide to updating it yourself."],
];

// Chatbot answers: k = keywords, a = answer (HTML allowed).
const BOT=[
  {k:["skill","tech","stack","know","tool"],a:'I design in Figma and build with HTML, CSS, JavaScript, React and Next.js. See <a href="#about">About</a>.'},
  {k:["project","app","website","work","portfolio","build"],a:'Browse apps, websites and design work on the <a href="#work">Work</a> page.'},
  {k:["price","cost","package","quote","budget"],a:'Every project gets a fixed quote within 24 hours. See the <a href="#services">packages</a>.'},
  {k:["award","certificate","credential"],a:'See certificates and recognition on the <a href="#awards">Awards</a> page.'},
  {k:["contact","email","hire","whatsapp","phone","reach"],a:'Email <a href="mailto:hello@example.com">hello@example.com</a> or use the <a href="#contact">Contact</a> page.'},
  {k:["resume","résumé","cv"],a:'Here is the <a href="#cv">one-page résumé</a>.'},
];
const CHIPS=["What are your skills?","Show me your projects","How much does it cost?","How can I contact you?"];

// One-page résumé (Résumé page).
const CV = {
  summary:"Product designer and front-end developer with 8 years of experience designing and building apps and websites for startups and small businesses.",
  skills:[["Design","Figma, user research, prototyping, design systems"],["Development","HTML, CSS, JavaScript, TypeScript, React, Next.js"],["Tools","Git, Vercel, Notion, Webflow"]],
  jobs:[
    ["Independent product designer & developer","Remote","2023 – Present",["Designed and built 12 apps and websites for startups","Northwind: delivery app that cut support calls by a third"]],
    ["Product designer","Lumen Labs","2020 – 2023",["Led design for a B2B analytics product used by 4,000 teams","Built the company design system"]],
    ["Junior web designer","Atlas Studio","2018 – 2020",["Designed and built marketing sites for local brands"]],
  ],
  projects:[["Northwind","Logistics app with live tracking"],["Bluepeak","Brand and online store"]],
  education:[["Bachelor of Design, Interaction Design, Example University","2016 – 2020"]],
  awards:["Google UX Design Certificate (2021)","Accessibility Fundamentals (2022)"],
};


// ============================================================
// Service pages for Google. Each entry becomes its own page at
// /services/<slug>/ so a search like "e-commerce website developer"
// can land straight on the matching service, not just the home page.
// After editing, run:  node tools/build-service-pages.mjs
// work: [title, image in /img, link, one line]. pkg: "dev" or "design" (from PACKAGES).
// bn: optional second-language section {h, p, faq:[[q,a]]} (named bn, but any language works).
// ============================================================
const SERVICE_PAGES = [
  {slug:"app-development",nav:"Apps",
   title:"App Developer · Mobile & Web App Development",
   h1:"Mobile and web apps people keep on their home screen",
   desc:"Mobile and web app development by Alex Morgan: installable apps with logins, dashboards, payments and offline mode.",
   kw:"app developer, mobile app developer, web app development, PWA developer, React developer",
   intro:"I build apps that install on Android, iPhone and desktop from one codebase, with accounts, dashboards and payments when you need them.",
   points:["Installable apps for Android, iOS and desktop (PWA)","Logins, dashboards and admin tools","Databases, payments and notifications"],
   work:[["Northwind","app-1.webp","/#work","A delivery-tracking app with a dispatcher dashboard."],["Ordering prototype","dev-ordering.webp","/demo/ordering-prototype.html","A clickable food ordering flow."]],
   pkg:"apps",
   faq:[["Can one app work on both Android and iPhone?","Yes. A progressive web app installs on both from a single codebase, which keeps cost and updates low."]]},
  {slug:"website-development",nav:"Websites",
   title:"Website Designer & Developer · Business Website Design",
   h1:"Business websites that load fast and get found on Google",
   desc:"Hire Alex Morgan to design and build your business website: fast, mobile-first, SEO-ready and live on your own domain.",
   kw:"website developer, website design, business website, web developer, freelance web developer, landing page design",
   intro:"I design and build websites for shops, restaurants, studios and small businesses. Every site is mobile-first, loads quickly, is set up for Google search, and goes live on your own domain.",
   points:["Business sites, landing pages and multi-page company websites","Contact form, WhatsApp button, maps and analytics","SEO setup: titles, sitemap, structured data and Search Console","Hosting, domain and SSL set up for you"],
   work:[["Bluepeak store","web-1.webp","/#work","An online store with Stripe checkout."],["Atlas Studio","web-2.webp","/#work","A business website with a simple CMS."]],
   pkg:"dev",
   faq:[["How long does a business website take?","A landing page usually takes a few days and a multi-page site one to three weeks, depending on content and feedback."],["Will my website show up on Google?","Every site is built with SEO basics in place. Nobody can promise a number-one ranking, but your site starts with everything Google needs."]]},
  {slug:"ui-ux-design",nav:"UI/UX design",
   title:"UI/UX Designer · App & Website Design",
   h1:"App and website design that people find easy to use",
   desc:"UI/UX design by Alex Morgan: wireframes, clickable prototypes, app screens and design systems.",
   kw:"UI/UX designer, UI designer, UX designer, app design, Figma designer, prototype",
   intro:"I design screens before any code is written, so you can click through your app or website first.",
   points:["Wireframes and clickable prototypes","Mobile app screens and website layouts","Design systems and developer handoff"],
   work:[["Checkout redesign","ui-1.webp","/#work","A simpler checkout flow."],["Dashboard UI","ui-2.webp","/#work","A clear analytics dashboard."]],
   pkg:"uiux",
   faq:[["What do I get from a UI/UX project?","Wireframes, final screens for phone and desktop, a clickable prototype and the design files."]]},
  {slug:"seo-services",nav:"SEO",
   title:"SEO Services · Get Your Website Found on Google",
   h1:"SEO that helps customers find you on Google",
   desc:"SEO services by Alex Morgan: technical SEO, keyword research, on-page optimisation, Google Search Console and Google Business Profile.",
   kw:"SEO services, SEO expert, local SEO, Google ranking, technical SEO, Google Business Profile",
   intro:"A website only brings customers if people can find it. I set up the technical side so Google can read your site properly, target the words your customers search for, and report what changed each month.",
   points:["Keyword research for your market","Titles, descriptions, headings and internal links","Sitemap and structured data","Search Console and Google Business Profile setup","Page speed fixes"],
   work:[["Bluepeak store","web-1.webp","/#work","Product pages built for search."]],
   pkg:"seo",
   faq:[["Can you guarantee the first position on Google?","No honest SEO can. What I can promise is a site Google can read properly, pages targeting the right searches, and clear monthly reports."],["How long does SEO take to work?","Technical fixes show up in days to weeks; competitive rankings usually take two to six months."]]},
  {slug:"ai-automation",nav:"AI agents & automation",
   title:"AI Agents, AI Assistants & Automation for Businesses",
   h1:"AI agents and automation that run the busy work for you",
   desc:"AI agents, AI assistants and business automation by Alex Morgan: agents that take bookings and orders, chat assistants for websites and WhatsApp, and automated workflows.",
   kw:"AI agent, AI assistant, AI automation, agentic AI, AI chatbot, WhatsApp chatbot, business automation, workflow automation, AI developer",
   intro:"I build three kinds of AI for businesses: assistants that answer your customers day and night, agents that go further and take real actions such as booking a table, placing an order or updating your CRM, and automations that run routine work on their own. Try the live AI agent prototype below to see every step it takes.",
   points:["AI agents that use your tools: bookings, orders, payments, CRM","AI assistants for your website or WhatsApp","Answers based on your own products, prices and FAQs","Automations: replies, follow-ups, reminders and daily reports","Connects forms, sheets, email, WhatsApp and your database","Hands over to a person whenever it isn't sure"],
   work:[["AI Agent Front Desk","dev-ai-agent.webp","/demo/ai-agent.html","A live prototype: an AI agent that books tables, takes orders, tracks deliveries and runs automations."],["Northwind","app-1.webp","/#work","Automated delivery updates for customers."]],
   pkg:"ai",
   faq:[["What is the difference between an AI assistant, an AI agent and AI automation?","An AI assistant answers questions. An AI agent also takes actions, such as booking a table, creating an order or updating your CRM. AI automation runs a fixed workflow on its own, such as a reminder or a nightly report."],["What can AI automation do for a small business?","Answer common questions instantly, take bookings, send follow-ups and produce reports, so you spend time on the work only you can do."],["Will the chatbot give wrong answers?","It answers from your own information and hands over to you when it isn't sure."]]},
  {slug:"portfolio-website",nav:"Portfolio sites",
   title:"Portfolio Website Design · Personal Portfolio Websites",
   h1:"A portfolio website that gets you hired",
   desc:"Get a personal portfolio website with light and dark themes, case studies, a résumé page and a private editor to update it yourself.",
   kw:"portfolio website, personal website, developer portfolio, designer portfolio, resume website",
   intro:"Your portfolio is often the first thing a recruiter or client sees. I build personal sites that show your work properly and let you update everything yourself.",
   points:["Light and dark themes","Case studies, galleries and a résumé page with PDF download","Private editor: change text and images without code","Google-ready SEO and social previews"],
   work:[["Atlas Studio","web-2.webp","/#work","A clean, image-first site."]],
   pkg:"dev",
   faq:[["Can I edit my portfolio after it is live?","Yes. You get a private login to edit text, add projects and change images, then publish."]]},
  {slug:"graphic-design",nav:"Graphic design",
   title:"Graphic Designer · Logo, Brand & Social Media Design",
   h1:"Logos, print and social media design for growing brands",
   desc:"Graphic design by Alex Morgan: logos, brand identity, menus, brochures and social media posts.",
   kw:"graphic designer, logo design, brand identity, menu design, social media design",
   intro:"I design complete brands: the logo, the print pieces and the social posts, all in one consistent style.",
   points:["Logo and brand identity","Menus, brochures and print-ready files","Social media posts and covers"],
   work:[["Brand identity","brand-1.webp","/#work","Logo and colour system."],["Print menu","print-1.webp","/#work","A print-ready menu."]],
   pkg:"design",
   faq:[["What files will I receive?","Print-ready PDFs, PNG and JPG files, and source files when the package includes them."]]},
];
