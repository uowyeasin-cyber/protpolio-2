# CLAUDE.md

Read [AGENTS.md](AGENTS.md): it is the codebase guide for this project (layout, data model, auth, conventions). Run `npm test` before finishing any change.
