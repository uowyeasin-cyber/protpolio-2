// Production Node server for Docker / VPS hosting (Vercel does not use this file).
// Serves the static site, runs the same /api/* handlers Vercel runs, and stores the
// owner's published edits and uploads in CMS_DATA_DIR (default ./.cms-data), or in
// Vercel Blob when BLOB_READ_WRITE_TOKEN is set.
//
//   OWNER_EMAIL=you@example.com OWNER_PASSWORD=secret node server.mjs
//
// Put HTTPS in front of it (Caddy, nginx, Cloudflare): the sign-in cookie is Secure,
// so Customise mode only works over https:// (or on http://localhost).
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const root = path.dirname(fileURLToPath(import.meta.url));

// Load .env (if present) without overriding variables that are already set.
try {
  for (const line of fs.readFileSync(path.join(root, ".env"), "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !line.trim().startsWith("#") && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, "$2");
  }
} catch {}

const TYPES = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".txt": "text/plain; charset=utf-8",
  ".xml": "application/xml; charset=utf-8", ".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg", ".gif": "image/gif", ".avif": "image/avif", ".svg": "image/svg+xml", ".ico": "image/x-icon",
  ".pdf": "application/pdf", ".mp4": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime",
  ".woff": "font/woff", ".woff2": "font/woff2",
};

// Source and config files that exist in the folder but are not part of the website.
const PRIVATE = /^\/(?:\.|node_modules\/|tools\/|tests\/|cms\/|docs\/|api\/_|server\.mjs$|package(?:-lock)?\.json$|Dockerfile$|docker-compose\.yml$|Caddyfile$|[A-Z][A-Z0-9_-]*\.md$|LICENSE$)/;

const SECURITY = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "X-Frame-Options": "SAMEORIGIN",
};

// api/_lib.js reads the same variable, so both always point at one folder.
process.env.CMS_DATA_DIR = path.resolve(root, process.env.CMS_DATA_DIR || ".cms-data");
const dataDir = () => process.env.CMS_DATA_DIR;

// Resolve a URL path inside base, or return null if it would leave base.
function inside(base, urlPath) {
  let rel;
  try { rel = decodeURIComponent(urlPath); } catch { return null; }
  if (rel.includes("\0")) return null;
  const file = path.resolve(base, "." + path.posix.normalize("/" + rel));
  return file === base || file.startsWith(base + path.sep) ? file : null;
}

function notFound(res) {
  const page = path.join(root, "404.html");
  res.writeHead(404, { ...SECURITY, "Content-Type": "text/html; charset=utf-8" });
  if (fs.existsSync(page)) fs.createReadStream(page).pipe(res);
  else res.end("<!doctype html><title>Not found</title><p>Page not found. <a href=\"/\">Go home</a></p>");
}

const handlers = new Map();
async function apiHandler(name) {
  if (!handlers.has(name)) {
    const file = path.join(root, "api", name + ".js");
    handlers.set(name, fs.existsSync(file) ? (await import(pathToFileURL(file).href)).default : null);
  }
  return handlers.get(name);
}

export function createServer({ dev = false } = {}) {
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, "http://local");

      const api = url.pathname.match(/^\/api\/([a-z][a-z-]*)\/?$/);
      if (api) {
        const handler = await apiHandler(api[1]);
        return handler ? await handler(req, res) : notFound(res);
      }

      if (req.method !== "GET" && req.method !== "HEAD") {
        res.writeHead(405, { ...SECURITY, Allow: "GET, HEAD" });
        return res.end();
      }

      let file;
      let extra = {};
      if (url.pathname.startsWith("/cms-files/")) {
        file = inside(dataDir(), url.pathname.slice("/cms-files".length));
        // Owner uploads: never let an uploaded SVG run scripts on this origin.
        extra = { "Content-Security-Policy": "default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'; sandbox" };
      } else {
        file = inside(root, url.pathname);
        // Check the decoded, normalised path so "/img/..%2fpackage.json" can't slip past.
        if (file && PRIVATE.test("/" + path.relative(root, file).split(path.sep).join("/"))) return notFound(res);
      }
      if (!file) return notFound(res);

      let st = fs.statSync(file, { throwIfNoEntry: false });
      if (st?.isDirectory()) {
        if (!url.pathname.endsWith("/")) {
          res.writeHead(308, { ...SECURITY, Location: url.pathname + "/" + url.search });
          return res.end();
        }
        file = path.join(file, "index.html");
        st = fs.statSync(file, { throwIfNoEntry: false });
      }
      if (!st || !st.isFile()) return notFound(res);

      const ext = path.extname(file).toLowerCase();
      const longCache = !dev && /^\/(img|vid|vendor)\//.test(url.pathname);
      res.writeHead(200, {
        ...SECURITY,
        ...extra,
        "Content-Type": TYPES[ext] || "application/octet-stream",
        "Content-Length": st.size,
        "Cache-Control": dev ? "no-store" : longCache ? "public, max-age=604800" : "public, max-age=0, must-revalidate",
      });
      if (req.method === "HEAD") return res.end();
      fs.createReadStream(file).pipe(res);
    } catch (err) {
      console.error(err);
      if (!res.headersSent) res.writeHead(500, { "Content-Type": "text/plain" });
      res.end("Server error");
    }
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = +process.env.PORT || 3000;
  const host = process.env.HOST || "0.0.0.0";
  createServer().listen(port, host, () => {
    console.log(`Portfolio Studio running on http://localhost:${port}`);
    if (!process.env.OWNER_EMAIL) console.log("Customise mode is off: set OWNER_EMAIL and OWNER_PASSWORD (see .env.example).");
    console.log("Storage:", process.env.BLOB_READ_WRITE_TOKEN ? "Vercel Blob" : dataDir());
  });
}
