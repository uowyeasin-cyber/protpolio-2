# Third-party notices

| Component | Licence | Where |
|---|---|---|
| @vercel/blob and its dependencies | Apache-2.0 / MIT | installed by `npm install` (see `node_modules/*/LICENSE`) |
| html2pdf.js (bundles jsPDF and html2canvas) | MIT | `vendor/html2pdf.bundle.min.js`, notice in `vendor/html2pdf.bundle.min.js.LICENSE.txt` |
| Geist, Geist Mono fonts | SIL Open Font License 1.1 | loaded from Google Fonts |
| Demo images in `img/` | Generated placeholders, free to use or replace | `img/` |
