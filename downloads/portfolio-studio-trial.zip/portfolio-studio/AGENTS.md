# AGENTS.md: codebase guide for AI coding tools (Claude Code, Cursor, Codex, etc.)

## What this is
Portfolio Studio is a static portfolio website (no framework, no build step for the site itself) plus a small set of Node.js serverless functions for an owner-only visual editor ("Customise mode").

## Layout
- `index.html`: the whole public site: CSS (design tokens at the top of `<style>`; dark theme under `:root[data-theme="dark"]`), markup for every view (`#v-home`, `#v-work`, `#v-code`, `#v-awards`, `#v-services`, `#v-about`, `#v-cv`, `#v-contact`, `#v-project`) and the hash router / renderer script.
- `data/content.js`: **all content** as plain JS constants: `SITE` (name, contacts, SEO), `PROJECTS`, `DEV`, `UIX`, `SERVICES`, `PACKAGES`, `EDU`, `EXP`, `SKILLS`, `CREDS`, `TESTIMONIALS`, `FAQ`, `BOT`, `CV`, `SERVICE_PAGES`. Each block has a comment describing its shape. Change content here, not in `index.html`.
- `data/i18n.js`: translated sentences for the service pages. `data/icons.js`: SVG icon set.
- `cms.js`: loaded by every visitor. Fetches `/api/content` and replays the owner's published edit operations (`ops`), hidden sections, extra pages and theme on top of the static page. Shows the login form on `/#login`.
- `cms/editor.src.js`: the editor UI. It is bundled into `api/_editor-src.js` by `npm run build:editor` and served only to a signed-in owner by `api/editor.js`. **Edit `cms/editor.src.js`, then run `npm run build:editor`. Never edit `api/_editor-src.js` by hand.**
- `api/*.js`: Vercel-style handlers `(req, res) => {}`. Shared helpers in `api/_lib.js` (auth, cookies, same-origin check, storage).
- `server.mjs`: production HTTP server for Docker/VPS. Serves static files (blocks source/config paths and path traversal) and dispatches `/api/<name>` to `api/<name>.js`.
- `tools/`: `dev-server.mjs`, `build-editor.mjs`, `build-service-pages.mjs` (writes `services/**`, `sitemap.xml`, `llms.txt`), `hash-password.mjs`, `indexnow.mjs`.
- `services/`: **generated** by `tools/build-service-pages.mjs`. Change `SERVICE_PAGES` in `data/content.js` and rebuild instead of editing.
- Licensing: `api/_licence.config.js` (`required:false` in the marketplace edition), `api/licence.js` (trial keys checked online with the seller's server, full licences `PSL1.` verified offline with Ed25519) and `licence-gate.js` (lock screen; only included in the trial edition's HTML).
- `tests/server.test.mjs`: Node built-in test runner. Run `npm test`.

## Data model (no database)
Storage is a list of files, Vercel Blob when `BLOB_READ_WRITE_TOKEN` is set, otherwise `CMS_DATA_DIR` on disk:
- `content/<ISO-timestamp>-<rand>.json`: one file per Publish: `{ v:1, ops:[], pages:[], hidden:[], theme:{} }`. Newest file = live. History/rollback = re-publishing an older file.
- `media/<timestamp>-<name>`: owner uploads (images, MP4/WebM, max ~4 MB).

## Auth
Single owner. `OWNER_EMAIL` + `OWNER_PASSWORD` (or scrypt `OWNER_PASSWORD_HASH`). Login sets an HMAC-signed, HttpOnly, Secure, SameSite=Strict cookie valid 14 days. Writes also require a same-origin `Origin` header. Login is rate-limited per IP (8 tries / 15 min, per instance).

## Conventions
- Plain ES modules, no TypeScript, no bundler, no framework. Keep it that way.
- Keep the site working with JavaScript-only static hosting: never make the public pages depend on the API being up (`cms.js` fails soft).
- Dark blue is the default theme. Keep both themes working when touching colours (use the CSS variables).
- Run `npm test` before committing. After editing `cms/editor.src.js` run `npm run build:editor`; after editing `SERVICE_PAGES`, `SITE.url` or services run `npm run build:pages`.
- Never commit `.env`, `.cms-data/` or `node_modules/`.
