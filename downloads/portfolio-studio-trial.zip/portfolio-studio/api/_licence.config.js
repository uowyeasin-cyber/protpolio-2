// Licence settings for this copy of Portfolio Studio.
// required: false  -> no licence check at all (marketplace edition).
// required: true   -> the site needs LICENCE_KEY: a trial key (checked online, limited runs)
//                     or a full licence (checked offline with publicKey, works forever).
export default {
  required: true,
  server: "https://yeasinarafatbd.vercel.app",
  trialUrl: "https://yeasinarafatbd.vercel.app/trial.html",
  buyWhatsApp: "60178151865",
  publicKey: "MCowBQYDK2VwAyEAbA2zE08UP7t64rFMPdL4ls/fAgGX8BziG8HHZp63T7M=",
};
