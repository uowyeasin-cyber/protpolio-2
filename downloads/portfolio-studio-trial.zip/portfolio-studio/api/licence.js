// Licence check for this site. The browser calls GET /api/licence once per page load
// (?new=1 on the first load of a browser session); the lock screen POSTs a pasted key.
//
// Key sources, first found wins: LICENCE_KEY environment variable, then a key pasted on
// the lock screen (saved in the site's storage: .cms-data or Vercel Blob).
import crypto from "node:crypto";
import cfg from "./_licence.config.js";
import { store, query, readJSON, send, sameOrigin } from "./_lib.js";

const TRIAL = /^PST-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;

// Full licence: PSL1.<payload>.<sig>, Ed25519-signed by the seller.
export function verifyFull(token, host) {
  const m = /^PSL1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/.exec(token || "");
  if (!m) return null;
  try {
    const pub = crypto.createPublicKey({ key: Buffer.from(cfg.publicKey, "base64"), format: "der", type: "spki" });
    if (!crypto.verify(null, Buffer.from("PSL1." + m[1]), pub, Buffer.from(m[2], "base64url"))) return null;
    const p = JSON.parse(Buffer.from(m[1], "base64url").toString());
    const h = String(host || "").split(":")[0].toLowerCase();
    const local = h === "localhost" || h === "127.0.0.1" || h.endsWith(".vercel.app");
    if (p.d && !local && h !== p.d && !h.endsWith("." + p.d)) return { ...p, wrongDomain: true };
    return p;
  } catch {
    return null;
  }
}

async function savedKey() {
  const items = await store.list("licence/").catch(() => []);
  if (!items.length) return "";
  return ((await store.getJSON(items[0]).catch(() => ({}))).key || "").trim();
}

async function status(key, host, session) {
  if (!key) return { status: "nokey" };
  if (key.startsWith("PSL1.")) {
    const p = verifyFull(key, host);
    if (!p) return { status: "invalid" };
    if (p.wrongDomain) return { status: "domain", domain: p.d };
    return { status: "active", name: p.n };
  }
  if (!TRIAL.test(key.toUpperCase())) return { status: "invalid" };
  try {
    const r = await fetch(cfg.server + "/api/licence?a=check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: key.toUpperCase(), host, session: Boolean(session) }),
      signal: AbortSignal.timeout(6000),
    });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } catch {
    return { status: "offline" }; // trials need the internet to count runs
  }
}

const OPEN = new Set(["active", "trial"]);

export default async function handler(req, res) {
  const host = req.headers["x-forwarded-host"] || req.headers.host || "";
  const info = { trialUrl: cfg.trialUrl, buyWhatsApp: cfg.buyWhatsApp };
  try {
    if (!cfg.required) return send(res, 200, { status: "active", ok: true });
    if (req.method === "POST") {
      if (!sameOrigin(req)) return send(res, 403, { error: "Bad origin." });
      const key = String((await readJSON(req, 4_000)).key || "").trim();
      const current = process.env.LICENCE_KEY || (await savedKey());
      // Only replace a key that is missing or not working, so visitors can't swap a working licence.
      const now = await status(current, host, false);
      // A full licence may always replace a trial key; anything else needs a broken current key.
      if (OPEN.has(now.status) && !(key.startsWith("PSL1.") && !current.startsWith("PSL1.")))
        return send(res, 409, { error: "This site already has a working licence." });
      const next = await status(key, host, true);
      if (!OPEN.has(next.status)) return send(res, 400, { ...info, ...next, ok: false, error: msg(next.status) });
      await store.put(`licence/${new Date().toISOString().replace(/[:.]/g, "-")}.json`, JSON.stringify({ key }), "application/json");
      return send(res, 200, { ...info, ...next, ok: true });
    }
    const key = process.env.LICENCE_KEY || (await savedKey());
    const s = await status(key, host, query(req).get("new") === "1");
    send(res, 200, { ...info, ...s, ok: OPEN.has(s.status) });
  } catch (e) {
    send(res, 500, { ...info, status: "error", ok: false });
  }
}

function msg(s) {
  return {
    nokey: "Paste your licence or trial key.",
    invalid: "That key is not valid. Check it and try again.",
    expired: "This trial has used all its free runs.",
    blocked: "This key has been blocked.",
    pending: "This trial key is waiting for approval.",
    offline: "Couldn't reach the licence server. Check your internet connection.",
    domain: "This licence is for a different domain.",
  }[s] || "This key can't be used.";
}
