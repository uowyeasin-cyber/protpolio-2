# Technical overview

| Item | Detail |
|---|---|
| Type | Portfolio website + owner-only visual CMS |
| Front end | Vanilla HTML, CSS and JavaScript (no framework, no build step) |
| Back end | 8 Node.js HTTP handlers in `api/` (Vercel Functions, or `server.mjs` on Docker/VPS) |
| Runtime | Node.js 18+ (tested on 22) |
| Dependencies | 1 runtime dependency: `@vercel/blob` (Apache-2.0). `npm audit`: 0 vulnerabilities |
| Database | None. Versioned JSON documents + media files in Vercel Blob or a local folder |
| Authentication | Single owner, email + password (plain or scrypt hash) from environment variables; HMAC-signed HttpOnly Secure SameSite=Strict session cookie (14 days); same-origin check on writes; login rate limit |
| Tests | `npm test` (Node built-in test runner): 9 tests covering pages, private-file blocking, path traversal, auth, publish/history, upload type checks, demo mode, licence |
| Fonts / libraries | Geist & Geist Mono (SIL OFL), html2pdf.js (MIT, bundled in `vendor/`) |

## Screens

Public (9 views + generated pages): Home, Work (8 categories + archive), Project case study (one per project, with lightbox gallery), Code, Awards, Services (packages, process, FAQ), About, Résumé (printable, Download PDF), Contact (brief form → WhatsApp/email). Plus 7 SEO service pages, a services hub, and a chatbot panel.

Owner (Customise mode): Login, edit bar (Edit, Publish, Undo/Redo), Element panel (text, images, links, buttons), Theme panel (colours, presets, fonts, sizes, site icon), Pages panel (add/hide pages and sections), History panel (versions and rollback), More panel.

## Data "tables"

There is no SQL database. Two collections of files:

| Collection | Path | Contents |
|---|---|---|
| Published versions | `content/*.json` | `{ v, ops[], pages[], hidden[], theme{} }`, one per Publish; newest is live |
| Media | `media/*` | Owner-uploaded images and short videos (≤ ~4 MB each) |

## API

| Route | Method | Access | Purpose |
|---|---|---|---|
| `/api/content` | GET | public | Latest published content (cached 5 s at the edge) |
| `/api/content?v=ID` | GET | owner | A specific version |
| `/api/content` | PUT | owner + same origin | Publish a new version |
| `/api/versions` | GET | owner | Version history |
| `/api/upload?name=` | POST | owner + same origin | Upload image/video |
| `/api/login` | POST | same origin, rate-limited | Sign in |
| `/api/logout` | POST | any | Sign out |
| `/api/me` | GET | any | Who is signed in |
| `/api/editor` | GET | owner | Editor script |
| `/api/icon` | GET | public | Site icon |

## Security notes
- No secrets in the code: all credentials come from environment variables (`.env.example` lists them).
- `server.mjs` blocks path traversal and refuses to serve source/config files (`package.json`, `api/_*`, `tools/`, `tests/`, `cms/`, dotfiles, docs). `vercel.json` does the same on Vercel.
- Uploaded files are type-checked (images, MP4/WebM only) and, on Docker/VPS, served with a sandboxing Content-Security-Policy.
- Security headers: `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `X-Frame-Options: SAMEORIGIN`.

## Server needs and hosting estimates

| Route | Needs | Typical cost |
|---|---|---|
| Vercel (Hobby) + Vercel Blob | none | $0/month for a personal portfolio (Hobby plan is for non-commercial use; Pro is $20/month) |
| Docker / VPS | 1 vCPU, 512 MB RAM, 1 GB disk | about $4–6/month (Hetzner, DigitalOcean, Vultr, Lightsail) |
| Domain | optional | about $10–15/year |

Page weight: about 180 KB HTML + content script, images lazy-loaded as WebP thumbnails.

## Build reproducibility
`package-lock.json` is committed; `npm ci` installs the exact same tree. The site needs no build. `npm run build` regenerates only the editor bundle and SEO pages from `data/content.js` (output is deterministic apart from the `lastmod` date in `sitemap.xml`). The `Dockerfile` builds from `node:22-alpine` with `npm ci --omit=dev`.
