# Portfolio Studio: free trial

This copy needs a key to run.

1. Install Node.js (LTS) from https://nodejs.org
2. In this folder run `npm install` then `npm run dev`
3. Open http://localhost:3000 and paste your trial key (`PST-XXXX-XXXX-XXXX-XXXX`) on the screen that appears.

Each new browser session counts as one run. The trial needs an internet connection.

**Buying a licence:** message the seller on WhatsApp (button on the lock screen) with your key. You'll get a full licence key (`PSL1.…`). Paste it on the lock screen, or put it in `.env` / Vercel as `LICENCE_KEY=…`. A full licence works forever and offline.

Everything else (setup, deploy, customise) is in README.md.
