// Licence gate: asks /api/licence whether this copy may run, and covers the page if not.
(function () {
  var SS = "ps-licence-session";
  var isNew = false;
  try { isNew = !sessionStorage.getItem(SS); } catch (e) {}

  var css =
    "#psl{position:fixed;inset:0;z-index:2147483647;background:rgba(4,8,18,.97);color:#E9EEF8;display:grid;place-items:center;padding:16px;font:16px/1.55 Geist,system-ui,sans-serif}" +
    "#psl .b{width:min(480px,100%);background:#0C1526;border:1px solid #1D2A43;border-radius:10px;padding:28px}" +
    "#psl h2{margin:0 0 8px;font-size:1.4rem;letter-spacing:-.01em}#psl p{margin:0 0 14px;color:#9BA9C2}" +
    "#psl input{width:100%;box-sizing:border-box;background:#131F36;border:1px solid #1D2A43;border-radius:8px;color:#E9EEF8;font:14px ui-monospace,monospace;padding:11px 12px;margin:4px 0 8px}" +
    "#psl .e{color:#FF6B6B;min-height:1.3em;font-size:.9rem;margin-bottom:8px}" +
    "#psl .r{display:flex;gap:8px;flex-wrap:wrap}#psl a,#psl button{flex:1;display:inline-flex;justify-content:center;align-items:center;border-radius:8px;padding:11px 14px;font:600 .95rem Geist,system-ui,sans-serif;cursor:pointer;text-decoration:none;border:1px solid #1D2A43;background:transparent;color:#E9EEF8;white-space:nowrap}" +
    "#psl button.p{background:#5B8CFF;border-color:#5B8CFF;color:#fff}" +
    "#pslt{position:fixed;left:12px;bottom:12px;z-index:2147483646;background:#0C1526;color:#E9EEF8;border:1px solid #1D2A43;border-radius:99px;padding:6px 12px;font:500 12px/1.4 Geist,system-ui,sans-serif;box-shadow:0 4px 18px #0006}" +
    "#pslt a{color:#86A8FF;margin-left:6px}";

  var TEXT = {
    nokey: ["Activate Portfolio Studio", "Paste your trial key or licence key to start. No key yet? Get a free trial key."],
    invalid: ["Key not recognised", "The key in this site is not valid. Paste a working trial or licence key."],
    expired: ["Your free trial has ended", "Thanks for trying Portfolio Studio! Buy a licence to keep using it. Paste the licence key you receive below."],
    blocked: ["This key is blocked", "Please contact the seller."],
    pending: ["Waiting for approval", "Your trial key is waiting for the seller's approval. Try again a little later."],
    offline: ["Can't check your trial", "The free trial needs an internet connection to start. Connect and reload."],
    domain: ["Licence is for another domain", "This licence was issued for a different website address."],
    error: ["Licence check failed", "Reload the page. If it keeps happening, contact the seller."],
  };

  function el(html) { var d = document.createElement("div"); d.innerHTML = html; return d.firstChild; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return "&#" + c.charCodeAt(0) + ";"; }); }
  function addCss() { if (!document.getElementById("psl-css")) { var s = document.createElement("style"); s.id = "psl-css"; s.textContent = css; document.head.appendChild(s); } }

  function buyLink(j) {
    return j.buyWhatsApp ? "https://wa.me/" + j.buyWhatsApp + "?text=" + encodeURIComponent("Hi, I want to buy a Portfolio Studio licence.") : "#";
  }

  function lock(j) {
    addCss();
    var t = TEXT[j.status] || TEXT.error;
    var box = el('<div id="psl" role="dialog" aria-modal="true" aria-labelledby="pslh"><div class="b">' +
      '<h2 id="pslh">' + esc(t[0]) + "</h2><p>" + esc(t[1]) + "</p>" +
      '<form><input name="k" placeholder="PST-XXXX-XXXX-XXXX-XXXX or PSL1.…" autocomplete="off" spellcheck="false" aria-label="Licence or trial key">' +
      '<div class="e" role="alert"></div><div class="r"><button class="p">Activate</button>' +
      (j.status === "nokey" && j.trialUrl ? '<a href="' + esc(j.trialUrl) + '" target="_blank" rel="noopener">Get free trial key</a>' : "") +
      '<a href="' + esc(buyLink(j)) + '" target="_blank" rel="noopener">Buy licence</a></div></form></div></div>');
    document.body.appendChild(box);
    document.documentElement.style.overflow = "hidden";
    var f = box.querySelector("form"), err = box.querySelector(".e");
    f.addEventListener("submit", function (e) {
      e.preventDefault();
      err.textContent = "";
      fetch("/api/licence", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ key: f.k.value.trim() }) })
        .then(function (r) { return r.json().then(function (x) { return [r.ok, x]; }); })
        .then(function (a) {
          if (!a[0]) { err.textContent = a[1].error || "That key can't be used."; return; }
          try { sessionStorage.setItem(SS, "1"); } catch (x) {}
          location.reload();
        })
        .catch(function () { err.textContent = "Couldn't save the key. Check your connection."; });
    });
    setTimeout(function () { f.k.focus(); }, 50);
  }

  function badge(j) {
    addCss();
    var left = Math.max(0, (j.limit || 0) - (j.used || 0));
    document.body.appendChild(el('<div id="pslt">Free trial · ' + left + " run" + (left === 1 ? "" : "s") + ' left<a href="' + esc(buyLink(j)) + '" target="_blank" rel="noopener">Buy licence</a></div>'));
  }

  function run() {
    fetch("/api/licence" + (isNew ? "?new=1" : ""), { credentials: "same-origin", cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j.ok) { try { sessionStorage.setItem(SS, "1"); } catch (e) {} }
        if (!j.ok) lock(j);
        else if (j.status === "trial") badge(j);
      })
      .catch(function () { lock({ status: "error" }); });
  }

  if (document.body) run(); else document.addEventListener("DOMContentLoaded", run);
})();
