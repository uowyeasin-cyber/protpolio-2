// Smoke tests for the server, the owner login and the editor API. Run: npm test
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "ps-test-"));
process.env.CMS_DATA_DIR = dataDir;
process.env.OWNER_EMAIL = "owner@example.com";
process.env.OWNER_PASSWORD = "correct horse battery";
delete process.env.BLOB_READ_WRITE_TOKEN;
delete process.env.OWNER_PASSWORD_HASH;

const { createServer } = await import("../server.mjs");
let server, base, origin;

before(async () => {
  server = createServer();
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  origin = `http://127.0.0.1:${server.address().port}`;
  base = origin;
});
after(() => {
  server.close();
  fs.rmSync(dataDir, { recursive: true, force: true });
});

const get = (p, opts) => fetch(base + p, { redirect: "manual", ...opts });
const login = (email, password) =>
  get("/api/login", { method: "POST", headers: { Origin: origin, "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });

test("home page and assets are served", async () => {
  const r = await get("/");
  assert.equal(r.status, 200);
  assert.match(r.headers.get("content-type"), /text\/html/);
  assert.equal(r.headers.get("x-content-type-options"), "nosniff");
  assert.match(await r.text(), /<html/i);
  for (const p of ["/data/content.js", "/cms.js", "/img/avatar.webp", "/services/", "/sitemap.xml", "/robots.txt"]) {
    assert.equal((await get(p)).status, 200, p);
  }
});

test("source, config and private files are not served", async () => {
  for (const p of ["/package.json", "/server.mjs", "/api/_lib.js", "/tools/dev-server.mjs", "/cms/editor.src.js", "/docs/CUSTOMISE.md", "/AGENTS.md", "/LICENSE", "/.env", "/.env.example", "/README.md", "/node_modules/@vercel/blob/package.json"]) {
    assert.equal((await get(p)).status, 404, p);
  }
});

test("path traversal is blocked", async () => {
  for (const p of ["/..%2f..%2f..%2fetc%2fpasswd", "/img/..%2f..%2fpackage.json", "/cms-files/..%2f..%2fetc%2fpasswd", "/%2e%2e/%2e%2e/etc/passwd"]) {
    const r = await get(p);
    assert.equal(r.status, 404, p);
  }
});

test("published content is public and empty by default", async () => {
  const r = await get("/api/content");
  assert.equal(r.status, 200);
  const body = await r.json();
  assert.equal(body.id, null);
  assert.deepEqual(body.content.ops, []);
});

test("editor and writes need the owner", async () => {
  assert.equal((await get("/api/editor")).status, 401);
  assert.equal((await (await get("/api/me")).json()).email, null);
  const put = await get("/api/content", { method: "PUT", headers: { Origin: origin, "Content-Type": "application/json" }, body: JSON.stringify({ v: 1, ops: [] }) });
  assert.equal(put.status, 401);
  assert.equal((await login("owner@example.com", "wrong password")).status, 401);
  assert.equal((await login("someone@else.com", "correct horse battery")).status, 401);
});

test("owner can sign in, publish, see history and upload", async () => {
  const r = await login("OWNER@example.com", "correct horse battery");
  assert.equal(r.status, 200);
  const cookie = r.headers.get("set-cookie").split(";")[0];
  const h = { Cookie: cookie, Origin: origin };

  assert.equal((await get("/api/editor", { headers: h })).status, 200);
  assert.equal((await (await get("/api/me", { headers: h })).json()).email, "owner@example.com");

  // Writes from another site are refused even with the cookie.
  const evil = await get("/api/content", { method: "PUT", headers: { ...h, Origin: "https://evil.example" }, body: JSON.stringify({ v: 1, ops: [] }) });
  assert.equal(evil.status, 403);

  const content = { v: 1, ops: [{ t: "text", sel: "h1", html: "Hello" }], pages: [], hidden: [], theme: {} };
  const put = await get("/api/content", { method: "PUT", headers: { ...h, "Content-Type": "application/json" }, body: JSON.stringify(content) });
  assert.equal(put.status, 200);
  const { id } = await put.json();

  const pub = await (await get("/api/content")).json();
  assert.equal(pub.id, id);
  assert.deepEqual(pub.content, content);

  const versions = await get("/api/versions", { headers: h });
  assert.equal(versions.status, 200);

  const png = Buffer.from("89504e470d0a1a0a", "hex");
  const up = await get("/api/upload?name=test.png", { method: "POST", headers: { ...h, "Content-Type": "image/png" }, body: png });
  assert.equal(up.status, 200);
  const { url } = await up.json();
  const file = await get(url);
  assert.equal(file.status, 200);
  assert.match(file.headers.get("content-security-policy"), /sandbox/);

  const bad = await get("/api/upload?name=x.html", { method: "POST", headers: { ...h, "Content-Type": "text/html" }, body: "<script>" });
  assert.equal(bad.status, 415);
});

test("demo mode lets people sign in but refuses writes", async () => {
  process.env.DEMO_MODE = "1";
  try {
    const r = await login("owner@example.com", "correct horse battery");
    const h = { Cookie: r.headers.get("set-cookie").split(";")[0], Origin: origin };
    assert.equal((await get("/api/editor", { headers: h })).status, 200);
    const put = await get("/api/content", { method: "PUT", headers: { ...h, "Content-Type": "application/json" }, body: JSON.stringify({ v: 1, ops: [] }) });
    assert.equal(put.status, 403);
    assert.match((await put.json()).error, /demo/);
  } finally {
    delete process.env.DEMO_MODE;
  }
});

test("licence check is off in the marketplace edition", async (t) => {
  if ((await import("../api/_licence.config.js")).default.required) return t.skip("trial edition");
  const r = await get("/api/licence?new=1");
  assert.equal(r.status, 200);
  assert.equal((await r.json()).ok, true);
});

test("full licence tokens are verified with the public key", async () => {
  const { verifyFull } = await import("../api/licence.js");
  assert.equal(verifyFull("PSL1.e30.AAAA", "localhost"), null);
  assert.equal(verifyFull("not-a-token", "localhost"), null);
});

