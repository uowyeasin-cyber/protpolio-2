# Portfolio Studio

> **Trial edition:** read [TRIAL.md](TRIAL.md) first. You need a trial or licence key to run it.

A premium, fast portfolio website for designers, developers and freelancers, with a private **Customise mode** so the owner can edit text, photos, colours, fonts and pages from the browser and press **Publish**. No coding is needed after setup.

- Dark blue theme by default, light theme on a toggle (remembered per visitor)
- Pages: Home, Work (8 categories + archive), Code, Awards, Services (packages, process, FAQ), About, a printable one-page Résumé with **Download PDF**, Contact (brief form that opens WhatsApp or email), and a case-study page per project
- Built-in chatbot ("Ask me anything") with your own answers
- Playable live demos and looping videos on project cards
- SEO built in: meta tags, Open Graph, schema.org, `sitemap.xml`, `robots.txt`, `llms.txt`, 7 search-ready service pages in 8 languages, IndexNow
- Owner-only editor with version history and one-click rollback
- Works from 320px phones to 2560px monitors

Everything you see is demo content ("Alex Morgan", example.com, placeholder images). Replace it with the real owner's details before launch: see [docs/CUSTOMISE.md](docs/CUSTOMISE.md).

A step-by-step setup guide in Banglish (Bangla in English letters) is in [docs/SETUP-GUIDE-BANGLA.md](docs/SETUP-GUIDE-BANGLA.md).

---

## What you need

| | Minimum |
|---|---|
| Node.js | 18 or newer (20 or 22 recommended) |
| npm | comes with Node.js |
| Hosting | **Route A** Vercel (free plan works) or **Route B** Docker / any Linux VPS with 512 MB RAM |
| Database | none: published edits and uploads are JSON and media files (Vercel Blob or a folder on disk) |

## 1. Run it on your computer (2 minutes)

```bash
cd portfolio-studio
npm install
cp .env.example .env          # Windows: copy .env.example .env
```

Open `.env` and set `OWNER_EMAIL` and `OWNER_PASSWORD`. Then:

```bash
npm run dev
```

The server reads `.env` by itself.

- Open http://localhost:3000 to see the site.
- Open http://localhost:3000/#login and sign in with the email and password from `.env`. The Customise bar appears at the bottom of the page.
- Local edits are saved in `.cms-data/`.

Run the automated checks any time with `npm test`.

## 2. Deploy

### Route A: Vercel (recommended, free)

1. Create a new GitHub repository and push this folder to it (or drag the folder into Vercel with the Vercel CLI: `npx vercel`).
2. In [Vercel](https://vercel.com), click **Add New → Project**, import the repository and press **Deploy**. Leave Framework as **Other**; no build command is needed.
3. In the project, open **Storage → Create → Blob**, create a store and connect it to the project. This adds `BLOB_READ_WRITE_TOKEN` automatically. Published edits and uploads live here.
4. In **Settings → Environment Variables** add:
   - `OWNER_EMAIL`: the owner's email (the only email that can sign in)
   - `OWNER_PASSWORD`: their password. Safer: use `OWNER_PASSWORD_HASH` instead, made with `npm run hash -- "the password"`
   - `SESSION_SECRET` (optional): any long random text
5. Open **Deployments**, press **⋯ → Redeploy** on the latest one, so the variables take effect.
6. Visit `https://your-site.vercel.app/#login`, sign in, change something, press **Publish**, and reload the page in a private window to check it is live.
7. **Domain:** **Settings → Domains → Add**, type the domain and follow the DNS records Vercel shows.

### Route B: Docker or any VPS (DigitalOcean, Hetzner, AWS Lightsail, cPanel with Node, etc.)

With Docker:

```bash
cp .env.example .env              # set OWNER_EMAIL and OWNER_PASSWORD
docker compose up -d --build      # site on http://SERVER-IP:3000
```

Edits and uploads are stored in the `cms-data` Docker volume, so they survive restarts and upgrades.

Without Docker (plain Node on a VPS):

```bash
npm ci --omit=dev
cp .env.example .env              # fill it in (server.mjs reads it)
npm start                         # or: pm2 start server.mjs --name portfolio
```

**HTTPS is required for signing in.** The login cookie is `Secure`, so Customise mode only works on `https://` (and on `http://localhost`). Easiest options:
- In `docker-compose.yml`, uncomment the `caddy` service, put the domain in `Caddyfile`, point the domain's A record at the server and run `docker compose up -d`. Caddy gets the certificate for you.
- Or put nginx + Certbot, or Cloudflare, in front of port 3000.

To keep edits on another disk, set `CMS_DATA_DIR=/path/to/folder`. To use Vercel Blob storage from a VPS, set `BLOB_READ_WRITE_TOKEN`.

**Backups (Route B):** copy the `CMS_DATA_DIR` folder (or the `cms-data` volume). That folder is the whole published state.

## 3. Make it the owner's site

Follow [docs/CUSTOMISE.md](docs/CUSTOMISE.md): fill `data/content.js` (name, contacts, projects, services, résumé, chatbot), replace images in `img/`, set SEO details, and run `npm run build` to regenerate the service pages and sitemap. Most text can also be changed later in Customise mode without touching code.

## Environment variables

| Name | Required | What it does |
|---|---|---|
| `OWNER_EMAIL` | yes (for Customise mode) | The only email allowed to sign in |
| `OWNER_PASSWORD` *or* `OWNER_PASSWORD_HASH` | yes (for Customise mode) | Owner password, plain or scrypt hash from `npm run hash` |
| `SESSION_SECRET` | no | Signs login cookies. Defaults to a value derived from the password |
| `BLOB_READ_WRITE_TOKEN` | Vercel: yes | Vercel Blob storage. Added automatically when you connect a Blob store |
| `CMS_DATA_DIR` | no | Folder for edits and uploads when Blob is not used. Default `./.cms-data` |
| `LICENCE_KEY` | trial edition only | Trial key (`PST-…`) or full licence (`PSL1.…`). Can also be pasted on the lock screen |
| `DEMO_MODE` | no | `1` = public demo: anyone with the demo login can try the editor, but Publish and uploads are refused |
| `PORT` | no | Port for `npm start` / Docker. Default `3000` |

Without `OWNER_EMAIL` and a password the public site still works perfectly; only Customise mode is switched off.

## Commands

| Command | What it does |
|---|---|
| `npm run dev` | Local server with caching off |
| `npm start` | Production server (Docker / VPS) |
| `npm test` | Automated checks: pages, private files, path traversal, login, publish, upload |
| `npm run build` | Rebuilds the editor bundle, service pages, `sitemap.xml` and `llms.txt` |
| `npm run hash -- "password"` | Makes an `OWNER_PASSWORD_HASH` value |

## Folder structure

```
index.html            page layout, styles and site engine
data/content.js       ALL content: name, contacts, projects, services, résumé, chatbot
data/i18n.js          translations for the service pages
data/icons.js         icon set
img/  vid/  demo/     images, videos, playable demos
cms.js                applies the owner's published edits for every visitor
cms/editor.src.js     the visual editor (sent only to the signed-in owner)
api/                  login, logout, me, content, versions, upload, editor, icon
server.mjs            production server for Docker / VPS
tools/                dev server, password hasher, editor and service-page builders, IndexNow
tests/                automated checks (npm test)
docs/                 customisation guide
```

More detail: [TECHNICAL.md](TECHNICAL.md) (architecture, security, hosting costs) and [AGENTS.md](AGENTS.md) (codebase guide for AI coding tools).

## Troubleshooting

| Problem | Fix |
|---|---|
| "The editor is not set up yet" | `OWNER_EMAIL` and `OWNER_PASSWORD` are missing. On Vercel, add them and **redeploy**. |
| Sign-in works but you are signed straight out (VPS) | You are on `http://`. Add HTTPS (see Route B). |
| "Wrong email or password" | Check for spaces in the variables. Changing the password needs a redeploy/restart. |
| "Too many attempts" | 8 wrong tries locks that IP for 15 minutes. |
| Publish fails on Vercel | The Blob store is not connected to this project, or you did not redeploy after connecting it. |
| Upload says "over 4 MB" | Compress the image (e.g. squoosh.app) or paste a link instead. |
| Changes don't show for visitors | Published content is cached for up to 30 seconds. Reload after a moment. |

## Support and updates

Support and updates are provided through the marketplace you bought from. See [CHANGELOG.md](CHANGELOG.md) for versions and [LICENSE](LICENSE) for terms.
